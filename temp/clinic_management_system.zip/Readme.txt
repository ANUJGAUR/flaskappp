conda create -n clinicmanagementenv python==3.10.0 -y
conda activate clinicmanagementenv


setupdatabase:
install xampp control panel 
start apache and mysql 
click on apache admin(it open the browser add :8080 to localhost) 
then website will open click on phpmyadmin to open database
